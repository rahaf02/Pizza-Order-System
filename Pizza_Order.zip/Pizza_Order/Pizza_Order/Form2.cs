﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_Order
{
    public partial class Form2 : Form
    {
        bool x = false;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            Form3 f = new Form3(this);
                
            string Pizza = listBox1.SelectedItem.ToString();

            string[] word = Pizza.Split('$');
            int Qty = Convert.ToInt32(comboBox1.SelectedItem);
            double price = double.Parse(word[1].ToString());
            double cost = price * Qty;
        

            if (radioButton1.Checked == true)
            {
                f.textBox1.Text = "Your Selection: " + listBox1.SelectedItem + "\r\n" + "Qty: " + Qty + "\r\n" + "Total Cost: " +   cost + "\r\n" + "Delivery option:" + radioButton1.Text; ;

            }
            if (radioButton2.Checked == true)
            {
                f.textBox1.Text = "Your Selection: " + listBox1.SelectedItem + "\r\n" + "Qty: " + Qty + "\r\n" + "Total Cost: " +  cost + "\r\n" + "Delivery option:" + radioButton2.Text; ;

            }
            if (radioButton3.Checked == true)
            {
                f.textBox1.Text = "Your Selection: " + listBox1.SelectedItem + "\r\n" + "Qty: " + Qty + "\r\n"+ "Total Cost: " +  cost + "\r\n" + "Delivery option:" + radioButton3.Text; ;

            }


          
            if (x == false)
            {
                f.Show();
                x = true;

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            comboBox1.ResetText();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
           
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        

        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
