﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_Order
{
    public partial class Form3 : Form
    {
        Form2 f  ;
        public Form3(Form2 F2)
        {
            InitializeComponent();
            f = F2;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
